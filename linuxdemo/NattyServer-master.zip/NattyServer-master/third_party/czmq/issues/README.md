# Issue test cases

This repository holds test cases for specific issues.

Each test case should be called issue-nnn and return 0 when successful, and assert if unsuccessful.

