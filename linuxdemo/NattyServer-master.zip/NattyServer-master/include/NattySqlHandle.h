/*
 *  Author : WangBoJing , email : 1989wangbojing@gmail.com
 * 
 *  Copyright Statement:
 *  --------------------
 *  This software is protected by Copyright and the information contained
 *  herein is confidential. The software may not be copied and the information
 *  contained herein may not be used or disclosed except with the written
 *  permission of Author. (C) 2016
 * 
 *
 
****       *****
  ***        *
  ***        *                         *               *
  * **       *                         *               *
  * **       *                         *               *
  *  **      *                        **              **
  *  **      *                       ***             ***
  *   **     *       ******       ***********     ***********    *****    *****
  *   **     *     **     **          **              **           **      **
  *    **    *    **       **         **              **           **      *
  *    **    *    **       **         **              **            *      *
  *     **   *    **       **         **              **            **     *
  *     **   *            ***         **              **             *    *
  *      **  *       ***** **         **              **             **   *
  *      **  *     ***     **         **              **             **   *
  *       ** *    **       **         **              **              *  *
  *       ** *   **        **         **              **              ** *
  *        ***   **        **         **              **               * *
  *        ***   **        **         **     *        **     *         **
  *         **   **        **  *      **     *        **     *         **
  *         **    **     ****  *       **   *          **   *          *
*****        *     ******   ***         ****            ****           *
                                                                       *
                                                                      *
                                                                  *****
                                                                  ****


 *
 */

#ifndef __NATTY_SQL_HANDLE__
#define __NATTY_SQL_HANDLE__


#include "NattyResult.h"


int ntyVoiceAckHandle(void *arg);

int ntyCommonAckHandle(void *arg);

int ntyVoiceDataReqHandle(void *arg);

int ntyVoiceReqHandle(void *arg);

int ntyBindConfirmReqHandle(void *arg);

int ntyOfflineMsgReqHandle(void *arg);
int ntyOfflineMsgCommonReqHandle(void *arg);

int ntyBindDeviceCheckStatusReqHandle(void *arg) ;

int ntyLocationBroadCastHandle(void *arg);

int ntyDeviceOfflineMsgReqHandle(void *arg);

int ntyCommonReqHandle(void *arg);

int ntyIOSPushHandle(void *arg);



#endif












