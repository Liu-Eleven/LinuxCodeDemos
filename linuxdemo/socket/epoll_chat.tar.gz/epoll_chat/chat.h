#ifndef __CHAT_H
#define __CHAT_H
#include "unixnet.h"
#include "ctype.h"
ssize_t writen(int fd, const void * vptr, size_t n);
ssize_t readn(int fd, void *vptr, size_t n);
#define MAXUSERS 10

struct chat_struct
{
    int sock_fd;
    char user_id[20];
    struct in_addr user_ipaddr;
    int next_char;
    int data_pos;
    struct client_cmd
    {
        int cmd_type;
        char user_id[20];
    } cmd;

    char buffer[MAXLINE];
    int slot_status;
    int user_assigned;
} chater[MAXUSERS];

/*定义用户槽位的状态*/
#define SLOT_FREED 0
#define SLOT_OCCUPIED 1
/*定义用户的命令*/
#define TELL_SOMEONE 1
#define CHAT_ALL 2
//空闲
//已占
/*定义用户输入的两种可能*/
#define CHATER_LOGOUT 1
#define CHATER_ENTER_A_CMD 2
//对应 tell 命令
//对应 chat 命令

//退出
//命令
char message[4][50]= {"too many users in the system.\n",
                      "can not find that user\n",
                      "input your user_id:",
                      "error command\n"
                     };
/*get_free_slot():为用户分配空闲槽柆,并初始化用户信息*/
void get_free_slot(int sock_fd ,char* user_name)
{
    int j,flags;
    printf("enter get_free_slot.\n");
    for(j=0; j<MAXUSERS ; j++)
    {
        if(chater[j].slot_status ==SLOT_FREED)
        {
            chater[j].slot_status =SLOT_OCCUPIED ;
            chater[j].sock_fd =sock_fd ;
            strcpy(chater[j].user_id ,user_name );
            chater[j].next_char =0;
            chater[j].user_assigned = 0;
            flags=fcntl(sock_fd,F_GETFL);
            if(flags==-1)
            {
                perror("get sock attributes error");
                exit(1);
            }
            else
            {
                flags|=O_NONBLOCK;
                if(fcntl(sock_fd,F_SETFL,flags)==-1)
                {
                    perror("change sock attributes error");
                    exit(1);
                }
            }
            break;
        }
    }
    if (j==MAXUSERS )
    {
        if(writen(sock_fd,message[0],strlen(message[0]))==-1)
        {
            perror("write to client error");
            exit(1);
        }
        close(sock_fd);
    }
}
/*根据连接描述符寻找槽位*/
int findSlotIndexByConnFd(int fd){
    int index = -1;
    int i = 0;
    for(i = 0;i < MAXUSERS;++i){
        if(chater[i].sock_fd == fd){
            index  = i;
        }
    }
    return index;
}


/*free_slot():释放用户槽位*/
void free_slot(int slot_index)
{
    chater[slot_index ].slot_status =SLOT_FREED ;
    close(chater[slot_index ].sock_fd );
}
/*find_chater():根据用户名查找该用户的槽位号*/
int find_chater(char* user_name )
{
    int i,ret;
    int j = 0;
    char tmp[100];
    for(i=0; i<MAXUSERS ; i++)
    {
        copyStringSkipSpace(tmp, chater[i].user_id);
        if(strcmp(tmp ,user_name)==0)
        {
            ret=i;
            break;
        }
    }
    if (i==MAXUSERS )
        ret=-1;
    return ret;
}
/*拷贝字符串直到遇到空格*/
void copyStringSkipSpace(char*dest,char*src){
    int j = 0;
    for(j = 0;j < strlen(src);++j){
        if(src[j] == '\0'||src[j]=='\n'||isspace(src[j])){
            dest[j] = '\0';
            break;
        }else{
            dest[j] = src[j];
        }
    }
}
void write_user(int receiver, int slot_index){
    writen(receiver ,chater[slot_index].user_id,strlen(chater[slot_index].user_id));
    writen(receiver ,": ",2);
}
/*tell_someone():执行 tell 命令*/
void tell_someone(int slot_index )
{
    int index,n;
    char *data_p;
    index=find_chater (chater[slot_index].cmd.user_id );
    if(index ==-1)
    {
        if(writen(chater[slot_index].sock_fd ,message[1],strlen(message[1])==-1))
        {
            perror("write to client error");
            exit(1);
        }
    }
    else
    {
        write_user(chater[index].sock_fd,slot_index);
        data_p =&(chater[slot_index].buffer
                  [chater[slot_index].data_pos ]);
        n=strlen(data_p );
        if(writen(chater[index].sock_fd ,data_p,n)==-1)
        {
            perror("chat_all error");
            exit(1);
        }
    }
}
/*chat_all():执行 chat 命令*/
void chat_all(int slot_index )
{
    int i,n;
    char* data_p;
    for(i=0; i<MAXUSERS; i++)
    {
        if(chater[i].slot_status !=SLOT_FREED&&slot_index!=i)
        {
            write_user(chater[i].sock_fd,slot_index);
            data_p=&(chater[slot_index].buffer
                     [chater[slot_index ].data_pos ]);
            n=strlen(data_p );
            if(writen(chater [i].sock_fd ,data_p,n)==-1)
            {
                perror("chat_all error");
                exit(1);
            }
        }
    }
}/*handle_cmd():命令分析及处理*/
void handle_cmd(int slot_index )
{
    char cmd[6];
    char user_id[20],*pos;
    char detail[MAXLINE ];
    int ret,i;
    pos=&(chater[slot_index ].buffer [0]);
    while (*pos==' '&&pos<&(chater[slot_index ].buffer [MAXLINE ]))
        pos++;
    if(*pos=='\n')
    {
        ret=writen(chater[slot_index].sock_fd ,message[3],strlen(message[3]))
            ;
        if (ret<0&&errno!=EWOULDBLOCK )
            free_slot(slot_index );
        return;
    }
    i=0;
    while (*pos!=' '&&pos<&(chater[slot_index ].buffer [MAXLINE ]))
    {
        cmd[i]=*pos++;
        i++;
    }
    cmd[i]='\0';
    if(strcmp("tell",cmd)==0)
    {
        while (*pos==' '&&pos<&(chater[slot_index ].buffer [MAXLINE] ))
            pos++;
        if(*pos=='\n')
        {
            ret=writen
                (chater[slot_index].sock_fd ,message[3],strlen(message[3]));
            if(ret<0&&errno!=EWOULDBLOCK)
                free_slot(slot_index);
            return;
        }
        i=0;
        while (*pos!=' '&&pos<&(chater[slot_index].buffer [MAXLINE]))
        {
            user_id [i]=*pos++;
            i++;
        }
        user_id[i]='\0';
        while (*pos==' '&&pos<&(chater[slot_index].buffer [MAXLINE ]))
            pos++;
        if(*pos=='\n')
        {
            ret=writen
                (chater[slot_index].sock_fd ,message[3],strlen(message[3]));
            if(ret<0&&errno!=EWOULDBLOCK)
                free_slot (slot_index);
            return;
        }
        chater[slot_index].data_pos =pos-chater[slot_index].buffer ;
        strcpy(chater[slot_index ].cmd .user_id ,user_id);
        chater[slot_index].cmd.cmd_type =TELL_SOMEONE ;
    }
    if(strcmp("chat",cmd)==0)
    {
        chater[slot_index ].cmd.cmd_type =CHAT_ALL ;
        chater[slot_index ].data_pos =pos-chater[slot_index ].buffer ;
    }
    if(chater[slot_index ].cmd.cmd_type ==TELL_SOMEONE ){
        tell_someone(slot_index );
    }
    if(chater[slot_index ].cmd.cmd_type ==CHAT_ALL ){
        printf("tell fucker");
        chat_all(slot_index );
    }
}
/*check_chater_status():检查用户状态*/
int check_chater_status(int slot_index)
{
    char *ptr;
    int n;
    ptr=&(chater[slot_index].buffer [chater[slot_index ].next_char ]);
    while((n=read(chater[slot_index ].sock_fd ,ptr,1))==1)
    {
        if(*ptr=='\n')
        {
            *(ptr+1)='\0';
            chater[slot_index ].next_char =0;
            return CHATER_ENTER_A_CMD ;
        }
        if(++chater[slot_index].next_char ==MAXLINE)
            --chater[slot_index ].next_char ;
        else
            ++ptr;
    }
    if (n==0)
        return CHATER_LOGOUT;
    if (n<0&&errno!=EWOULDBLOCK )free_slot (slot_index);
    return 0;
}
/*writen():向套接字写,工作于无阻塞模式*/
ssize_t writen (int fd,const void *vptr,size_t n)
{
    size_t nleft;
    ssize_t nwritten;
    const char *ptr;
    ptr=vptr;
    nleft=n;
    while (nleft>0)
    {
        if((nwritten=write(fd,ptr,nleft))<=0)
        {
            if(errno==EWOULDBLOCK)
            {
                nwritten =0;
            }
            else
                return -1;
        }
        nleft-=nwritten;
        ptr+=nwritten;
    }
    return n;
}
/*readen():从套接字读,工作于无阻塞方式*/
ssize_t readn(int fd,void * vptr,size_t n)
{
    size_t nleft;
    ssize_t nread;
    char *ptr;
    ptr=vptr;
    nleft=n;
    while(nleft>0)
    {
        if((nread=read(fd,ptr,nleft))<0)
        {
            if(errno==EWOULDBLOCK)
                nread=0;
            else
                return -1;
        }
        else if(nread==0)
            break;
        nleft-=nread;
        ptr+=nread;
    }
    return(n-nleft);
}
/*my_common_read():从 read_buf 缓冲区中返回一字节数据*/
static ssize_t my_common_read(int fd,char *ptr)
{
    static int read_cnt=0;
    static char *read_ptr;
    static char read_buf[MAXLINE];
    if(read_cnt<=0)
    {
again:
        if((read_cnt=read(fd,read_buf,sizeof(read_buf)))<=0)
        {
            if (errno==EINTR) goto again;
            return -1;
        }
        else if(read_cnt==0)
            return 0;
        read_ptr=read_buf;
    }
    read_cnt--;
    *ptr=*read_ptr ++;
    return 1;
}
/*commonreadline():读一行数据,搜索记录边界即回车换行*/
ssize_t commonreadline(int fd,void *vptr,size_t maxlen)
{
    int n,rc;
    char c,*ptr;
    static times=0;
    ptr=vptr ;
    for(n=1; n<maxlen; n++)
    {
        if((rc=my_common_read(fd,&c))==1)
        {
            *ptr=c;
            ptr++;
            if(c=='\n')
            {
                times++;
                if(times==1)
                {
                    break;
                }
            }
            else
                times=0;
        }
        else if (rc==0)
        {
            if (n==1) return 0;
            else
                break;
        }
        else
            return -1;
    }
    *ptr=0;
    return n;
}
#endif
